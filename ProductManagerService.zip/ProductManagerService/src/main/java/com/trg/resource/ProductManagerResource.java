package com.trg.resource;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.trg.model.Product;

@RestController
@RequestMapping("/productManager")
public class ProductManagerResource {

	@Autowired
	RestTemplate restTemplate;
	
	//static final String REST_URI = "http://localhost:8083/productCatalog/";
	static final String REST_URI = "http://PRODUCT-CATALOG-SERVICE/productCatalog/";

	Product p = new Product();
	
	@RequestMapping("/{category}")
	public List<Product> getCatalog(@PathVariable("category") String category) {
		List<Product>  filterList = new ArrayList<Product>();
		
		List<LinkedHashMap<String, Object>> products = 
				restTemplate.getForObject(REST_URI + category , List.class);

		if (products != null) {
			for (LinkedHashMap<String, Object> map : products){
				p.setProdId((Integer)map.get("prodId"));
				p.setPname((String)map.get("pname"));
				p.setCat((String)map.get("cat"));
				p.setPrice((Integer)map.get("price"));
				filterList.add(p);
			}
		} else
			System.out.println("No course exists----------");
		return filterList;
	}
}
