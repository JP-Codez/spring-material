package com.hsbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CurrencyConverter  {

	@Autowired  //field level
	ExchangeService exchangeService;
	
	public ExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}


	/*double exchRate;
	
	public CurrencyConverter(double exchRate) {
		this.exchRate = exchRate;
	}

	public double getExchRate() {
		return exchRate;
	}

	public void setExchRate(double exchRate) {
		this.exchRate = exchRate;
	}*/

	

	public double dollarsToRs(int amt) {
		return amt * exchangeService.getRate();
	}

}
