package com.hsbc;

public class HelloWorld {
	
	public void sayHello() {
		System.out.println("Hello World");
	}

}
