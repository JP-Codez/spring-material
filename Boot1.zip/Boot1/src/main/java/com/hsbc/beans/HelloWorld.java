package com.hsbc.beans;


public class HelloWorld {
	
	public void sayHello() {
		System.out.println("Hello World");
	}

}
