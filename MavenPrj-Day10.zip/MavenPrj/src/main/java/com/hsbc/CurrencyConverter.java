package com.hsbc;

public class CurrencyConverter  {
	
	ExchangeService exchangeService;
	
	public ExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}

	public double dollarsToRs(int amt) {
		return amt * exchangeService.getRate();
	}

}
