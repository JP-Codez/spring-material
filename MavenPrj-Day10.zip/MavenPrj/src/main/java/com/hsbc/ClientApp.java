package com.hsbc;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClientApp {
	
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
		HelloWorld hw = ctx.getBean("hello", HelloWorld.class);
		hw.sayHello();
		
		User u = ctx.getBean("user", User.class);
		System.out.println(u);
	}

}
