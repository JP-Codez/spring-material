package com.hsbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CurrClientApp {
	
	public static void main(String[] args) {
		/*CurrencyConverter cc = new CurrencyConverter();
		cc.setExchRate(75.2);
		System.out.println(cc.dollarsToRs(1000));*/
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
		CurrencyConverter ccobj = ctx.getBean("currencyConverter", CurrencyConverter.class);
		System.out.println(ccobj.dollarsToRs(100));
		
		
		
	}

}
