package com.hsbc;

public class ExchangeService {
	
	public double getRate(){
		//complex code, hit some web service, 
		return 77.0;
	}

}
