package com.hsbc;

public interface CurrencyConverterIntf {
	
	public double dollarsToRs(int rs);

}
