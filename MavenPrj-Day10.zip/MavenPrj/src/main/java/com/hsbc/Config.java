package com.hsbc;

import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	
	@Bean
	public HelloWorld hello() {
		return new HelloWorld();
	}
	
	@Bean
	public User user() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter username");
		String un = sc.next();
		
		User user = new User();
		user.setUname(un);
		return user;
	}

	@Bean
	public CurrencyConverter cc() {
		CurrencyConverter cc1 = new CurrencyConverter();
		cc1.setExchangeService(es());
		return cc1;
	}
	
	@Bean
	public ExchangeService es() {
		return new ExchangeService();
	}
}










