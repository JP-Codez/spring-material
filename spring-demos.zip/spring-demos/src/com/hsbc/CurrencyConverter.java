package com.hsbc;

import org.springframework.beans.factory.annotation.Required;

public class CurrencyConverter  {

	double exchRate;

	public double getExchRate() {
		return exchRate;
	}

	@Required   //setter level annotation
	public void setExchRate(double exchRate) {
		this.exchRate = exchRate;
	}

	public double dollarsToRs(int amt) {
		return amt * exchRate;
	}

}
