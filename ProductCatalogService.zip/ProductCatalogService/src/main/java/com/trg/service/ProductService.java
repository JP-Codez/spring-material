package com.trg.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.trg.model.Product;

@Service
public class ProductService {

	List<Product> prodlist = new ArrayList<>();
	
	public ProductService() {
		prodlist.add(new Product(101, "Prod-1", "cat1", 3000));
		prodlist.add(new Product(102, "Prod-2", "cat2", 4000));
		prodlist.add(new Product(103, "Prod-3", "cat1", 2000));
		prodlist.add(new Product(104, "Prod-4", "cat2", 5000));
		prodlist.add(new Product(105, "Prod-5", "cat1", 3500));	
	}

	public List<Product> getProductByCategory(String cat) {
		  List<Product> plist = new ArrayList<>();
		  
		  for(Product p : prodlist){
			  if(p.getCat().equals(cat))
				  plist.add(p);
		  }
		  return plist;
	}

}
