package com.trg.resource;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.trg.model.Product;
import com.trg.service.ProductService;

@RestController
@RequestMapping("/productCatalog")
public class ProductCatalogResource {

	@Autowired
	ProductService productService;
	
	@RequestMapping("/{category}")
	public List<Product> getCatalog(@PathVariable("category") String category) {
		List<Product> list = productService.getProductByCategory(category);
		return list;
	}
}
