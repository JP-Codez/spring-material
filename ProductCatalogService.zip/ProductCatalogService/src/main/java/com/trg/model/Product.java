package com.trg.model;

public class Product {
	int prodId;
	String pname;
	String cat;
	int price;

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int prodId, String pname, String cat, int price) {
		super();
		this.prodId = prodId;
		this.pname = pname;
		this.cat = cat;
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
}
