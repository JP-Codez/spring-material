package com.hsbc.controller;

import java.util.Date;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SimpleController {

	@RequestMapping("/processUser")
	public String m3(@RequestParam("t1") String uname, Model model) {
		model.addAttribute("username", uname);
		return "welcome";
	}
	
	
	
	
	
	@RequestMapping("/hello")
	public String m1() {
		return "welcome";
	}

	
	@RequestMapping("/greet")
	public String m2(Model model) {
		Date d1 = new Date();
		model.addAttribute("today", d1);
		model.addAttribute("username", "shrilata");
		return "greet";
	}
}
